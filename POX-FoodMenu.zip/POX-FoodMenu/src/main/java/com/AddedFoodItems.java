/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAttribute;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
/**
 *
 * @author Shruti Sonawane
 */
@XmlRootElement(name = "AddedFoodItems", namespace="http://cse564.asu.edu/PoxAssignment")
@XmlAccessorType(XmlAccessType.FIELD)
public class AddedFoodItems 
{
    @XmlElement(name = "FoodItemAdded", namespace="http://cse564.asu.edu/PoxAssignment")
    private  List<FoodItemAdded> foodItemAdded;
    
    @XmlElement(name = "FoodItemExists", namespace="http://cse564.asu.edu/PoxAssignment")
    private List<FoodItemExists> foodItemExists;

    /**
     * @return the foodItemAdded
     */
    public List<FoodItemAdded> getFoodItemAdded() {
        return foodItemAdded;
    }

    /**
     * @param foodItemAdded the foodItemAdded to set
     */
    public void setFoodItemAdded(List<FoodItemAdded> foodItemAdded) {
        this.foodItemAdded = foodItemAdded;
    }

    /**
     * @return the foodItemExists
     */
    public List<FoodItemExists> getFoodItemExists() {
        return foodItemExists;
    }

    /**
     * @param foodItemExists the foodItemExists to set
     */
    public void setFoodItemExists(List<FoodItemExists> foodItemExists) {
        this.foodItemExists = foodItemExists;
    }
}
