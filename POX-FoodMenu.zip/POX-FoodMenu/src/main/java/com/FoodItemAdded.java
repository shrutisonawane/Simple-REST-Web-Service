/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAttribute;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

/**
 *
 * @author Shruti Sonawane
 */
@XmlRootElement(name = "FoodItemAdded", namespace="http://cse564.asu.edu/PoxAssignment")
@XmlAccessorType(XmlAccessType.FIELD)
public class FoodItemAdded 
{
    
        @XmlElement(name = "FoodItemId", namespace="http://cse564.asu.edu/PoxAssignment")      
        private String FoodItemId;

        public String getFoodItemId() 
        {
            return FoodItemId;
        }

        public void setFoodItemId(String FoodItemId) 
        {
            this.FoodItemId = FoodItemId;
        }
    
       
}
