/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAttribute;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
/**
 *
 * @author Shruti Sonawane
 */
@XmlRootElement(name = "FoodItemData")
@XmlAccessorType(XmlAccessType.FIELD)
public class FoodItemData 
{
 
    @XmlElement(name = "FoodItem")
    private List<FoodItemData.FoodItem> foodItems;

    public List<FoodItemData.FoodItem> getFoodItems() 
    {
        return foodItems;
    }
    public void setFoodItems(List<FoodItemData.FoodItem> foodItems) 
    {
        this.foodItems = foodItems;
    }
     
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class FoodItem
    {
    @XmlAttribute(name = "country")      
    private String country;
    
    @XmlElement(name = "id")
    private String id;
    
    @XmlElement(name = "name")
    private String name;
    
    @XmlElement(name = "description")
    private String description;
    
    @XmlElement(name = "category")
    private String category;
    
    
    @XmlElement(name = "price")
    private double price;


    //getters
    public String getCountry() 
    {
        return country;
    }
    
    public String getId() 
    {
        return id;
    }
    
    public String getName() 
    {
        return name;
    }
    
    public String getDescription() 
    {
        return description;
    }
    
    public String getCategory() 
    {
        return category;
    }
    
    public double getPrice() 
    {
        return price;
    }
    
    //setters
    public void setCountry(String country)
    {
        this.country= country;
    }

    public void setId(String id)
    {
        this.id= id;
    }

    public void setName(String name)
    {
        this.name= name;
    }

    public void setDescription(String description)
    {
        this.description= description;
    }

    public void setCategory(String category)
    {
        this.category= category;
    }

    public void setPrice(double price)
    {
        this.price= price;
    }

    } 
}
