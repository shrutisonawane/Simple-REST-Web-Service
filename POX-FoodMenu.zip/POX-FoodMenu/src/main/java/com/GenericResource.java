package com;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Marshaller;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
//import com.MyServletContextListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * REST Web Service
 *
 * @author Shruti Sonawane
 */
@Path("generic")
public class GenericResource extends HttpServlet
{
    private static final Logger LOG = LoggerFactory.getLogger(GenericResource.class);
    
    public GenericResource() 
    {
        LOG.info("Creating a GenericResource Resource");
    }
    
    private CharSequence NEW_FOOD_ITEMS = "NewFoodItems";
    private CharSequence SELECTED_FOOD_ITEMS = "SelectedFoodItems";
        
    public int maxID;
    public HashMap<String,FoodItemData.FoodItem> foodRepository;
    public HashMap<String,FoodItemData.FoodItem> foodIDRepository;
            
    @POST
    @Produces(MediaType.APPLICATION_XML)
    @Consumes(MediaType.APPLICATION_XML)
    public Response FoodProcessingMethod(String content, @Context HttpServletRequest request)
    {
        System.out.println("inside FoodProcessingMethod!!");
        foodRepository = (HashMap<String,FoodItemData.FoodItem>)request.getServletContext().getAttribute("foodRepository");
        foodIDRepository = (HashMap<String,FoodItemData.FoodItem>)request.getServletContext().getAttribute("foodIDRepository");
        System.out.println("just before maxID...");
               
        maxID = (int)request.getServletContext().getAttribute("maxID");
        
        StringReader input = new StringReader(content);
        Response myResponse = null;
        try
        {
           if(content.contains(NEW_FOOD_ITEMS))
           {
               LOG.info("We have a new food item!!");
               JAXBContext jaxbContext = JAXBContext.newInstance(NewFoodItems.class);
               Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
               NewFoodItems newFoodItems = (NewFoodItems)jaxbUnmarshaller.unmarshal(input);
               
               System.out.println("Size"+newFoodItems.getNewFoodItems().size());
               AddedFoodItems addedFood = new AddedFoodItems();
               addedFood = AddNewFoodItem(newFoodItems,request);
               myResponse = Response.ok(addedFood).build();
               //return myResponse;
           }
           else if(content.contains(SELECTED_FOOD_ITEMS))
           {
               JAXBContext jaxbContext = JAXBContext.newInstance(SelectedFoodItems.class);
               Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
               SelectedFoodItems selectedFood = (SelectedFoodItems) jaxbUnmarshaller.unmarshal(input);
               RetrievedFoodItems fd = new RetrievedFoodItems();
               fd = RetrieveFood(selectedFood,request);
               myResponse = Response.ok(fd).build();
               //return myResponse;
           } 
           else
           {
               InvalidMessage error = new InvalidMessage();
               error.setErrorMessage("Encountered an invalid input");
               myResponse = Response.ok(error).build();
           }
           
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
       return myResponse; 
    }
     
    
    public String FindExistingFood(String foodName)
    {
        String retVal="";
        System.out.println("inside FindExistingFood");
        Iterator itr= foodRepository.entrySet().iterator();
        while(itr.hasNext())
        {
            Map.Entry<String,FoodItemData.FoodItem> record = (Entry<String,FoodItemData.FoodItem>)itr.next();
            if(record.getKey().equals(foodName))          //record.getValue().getName().equals(foodName))
            {
                retVal= record.getValue().getId();
            }
            else
                retVal= "boo";       //record.getValue().getId();
        }
        return retVal;
    }
          
    
     
    public RetrievedFoodItems RetrieveFood(SelectedFoodItems select,@Context HttpServletRequest request)
    {
        RetrievedFoodItems response = new RetrievedFoodItems();
        List<RetrievedFoodItems.FoodItem> retFoodList = new ArrayList<RetrievedFoodItems.FoodItem>();
        List<RetrievedFoodItems.FoodItemId> invalidIDList = new ArrayList<RetrievedFoodItems.FoodItemId>();
        
        for(String fid:select.getSelectedFoodItems())
        {
            String temp = fid;
            System.out.println("selected id: "+ temp);
            RetrievedFoodItems.FoodItem item = new RetrievedFoodItems.FoodItem();
            
            if(foodIDRepository.containsKey(temp))
            {                
                item.setCategory(foodIDRepository.get(temp).getCategory());
                item.setCountry(foodIDRepository.get(temp).getCountry());
                item.setDescription(foodIDRepository.get(temp).getDescription());
                item.setId(foodIDRepository.get(temp).getId());
                item.setPrice(foodIDRepository.get(temp).getPrice());
                item.setName(foodIDRepository.get(temp).getName());
                retFoodList.add(item);
            }
            else
            {
                RetrievedFoodItems.FoodItemId invID= new RetrievedFoodItems.FoodItemId();
                invID.setFoodItemId(temp);
                invalidIDList.add(invID);
            }
        }
        response.setInvalidFoodItems(invalidIDList);
        response.setRetrievedFoodItems(retFoodList);
        return response;
    }
    
    
     public AddedFoodItems AddNewFoodItem(NewFoodItems newFoodItems, @Context HttpServletRequest request)
        {
            System.out.println("inside AddedFoodItems");
           AddedFoodItems response = new AddedFoodItems();
           List<FoodItemAdded> addedList = new ArrayList<FoodItemAdded>();
           List<FoodItemExists> existsList = new ArrayList<FoodItemExists>();
           for(NewFoodItems.FoodItem foodItem : newFoodItems.getNewFoodItems())
           {
               if(foodRepository.containsKey(foodItem.getName()))
               {
                   FoodItemExists exists = new FoodItemExists();
                   //to-do
                   exists.setFoodItemId(foodRepository.get(foodItem.getName()).getId());
                   existsList.add(exists);
                   
               }
               else
               {
                   FoodItemAdded added = new FoodItemAdded();
                   //to-do
                   FoodItemData.FoodItem fd = new FoodItemData.FoodItem();
                   fd.setId(String.valueOf(maxID+1));
                   fd.setCategory(foodItem.getCategory());
                   fd.setCountry(foodItem.getCountry());
                   fd.setDescription(foodItem.getDescription());
                   fd.setName(foodItem.getName());
                   fd.setPrice(foodItem.getPrice());
                                      
                   added.setFoodItemId(String.valueOf(maxID+1));
                   addedList.add(added);
                   request.getServletContext().setAttribute("maxID",maxID+1);
                     
                   foodIDRepository.put(String.valueOf(maxID+1), fd);
                   request.getServletContext().setAttribute("foodIDRepository", foodIDRepository);
                                      
                   foodRepository.put(fd.getName(), fd);
                   request.getServletContext().setAttribute("foodRepository", foodRepository);
                   
                   
               }
               response.setFoodItemExists(existsList);
               response.setFoodItemAdded(addedList);
               
           }
           
           return response;
            
        }
    
    
    
       
    
}
