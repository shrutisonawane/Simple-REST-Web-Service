package com;
import java.io.File;
//import java.util.Collections;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.util.HashMap;
import javax.servlet.annotation.WebListener;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

/**
 *
 * @author Shruti Sonawane
 */
@WebListener
public class MyServletContextListener implements ServletContextListener
{
    String filePath; // = "C:\\Users\\Shruti Sonawane\\Documents\\NetBeansProjects\\POX-FoodMenu\\FoodItemData.xml";
    static FoodItemData food;

    @Override
    public void contextDestroyed(ServletContextEvent arg0) 
    {
	System.out.println("ServletContextListener destroyed");
    }
    
    //Run this before web application is started
    @Override
    public void contextInitialized(ServletContextEvent arg0) 
    {
        int maxID = 0;  //Integer.MIN_VALUE;
        HashMap<String,FoodItemData.FoodItem> foodRepository = new HashMap<>();
        HashMap<String,FoodItemData.FoodItem> foodIDRepository = new HashMap<>();
        try
        {
          
         //System.out.println("Made it beyond maxID in context listener");
        
           filePath = arg0.getServletContext().getRealPath("/")+"WEB-INF"+"\\FoodItemData.xml";
           System.out.println("relative path "+filePath);
           JAXBContext jaxbContext = JAXBContext.newInstance(FoodItemData.class);
           Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
           food = (FoodItemData) jaxbUnmarshaller.unmarshal(new File(filePath)); 
           
           for(FoodItemData.FoodItem foo:food.getFoodItems())
           {
               foodRepository.put(foo.getName(), foo);
               //System.out.println(foo.getName());
               if(Integer.parseInt(foo.getId())> maxID)
                   maxID = Integer.parseInt(foo.getId());
               
               foodIDRepository.put(foo.getId(),foo);
           }

           arg0.getServletContext().setAttribute("foodRepository", foodRepository);
           arg0.getServletContext().setAttribute("foodIDRepository", foodIDRepository);
           arg0.getServletContext().setAttribute("maxID", maxID);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.out.println("Exception is: "+e);
        }      
    }
    
 }
