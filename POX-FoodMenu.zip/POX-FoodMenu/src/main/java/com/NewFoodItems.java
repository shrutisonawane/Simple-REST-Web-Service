/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAttribute;

import java.util.List;
import javax.servlet.ServletContextListener;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
/**
 *
 * @author Shruti Sonawane
 */
@XmlRootElement(name = "NewFoodItems", namespace="http://cse564.asu.edu/PoxAssignment")
@XmlAccessorType(XmlAccessType.FIELD)
public class NewFoodItems 
{
    @XmlElement(name = "FoodItem", namespace="http://cse564.asu.edu/PoxAssignment")
    protected List<NewFoodItems.FoodItem> newFoodItems;
    
    public List<NewFoodItems.FoodItem> getNewFoodItems() 
    {
        return newFoodItems;
    }
    public void setNewFoodItems(List<NewFoodItems.FoodItem> foodItems) 
    {
        newFoodItems = foodItems;
    }
    
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class FoodItem
    {
      @XmlAttribute(name = "country")      
      private String country;
    
      @XmlElement(name = "name", namespace="http://cse564.asu.edu/PoxAssignment")
      private String name;
    
      @XmlElement(name = "description", namespace="http://cse564.asu.edu/PoxAssignment")
      private String description;
    
      @XmlElement(name = "category", namespace="http://cse564.asu.edu/PoxAssignment")
      private String category;
    
      @XmlElement(name = "price", namespace="http://cse564.asu.edu/PoxAssignment")
      private double price;

        /**
         * @return the country
         */
        public String getCountry() {
            return country;
        }

        /**
         * @param country the country to set
         */
        public void setCountry(String country) {
            this.country = country;
        }

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        /**
         * @param name the name to set
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * @return the description
         */
        public String getDescription() {
            return description;
        }

        /**
         * @param description the description to set
         */
        public void setDescription(String description) {
            this.description = description;
        }

        /**
         * @return the category
         */
        public String getCategory() {
            return category;
        }

        /**
         * @param category the category to set
         */
        public void setCategory(String category) {
            this.category = category;
        }

        /**
         * @return the price
         */
        public double getPrice() {
            return price;
        }

        /**
         * @param price the price to set
         */
        public void setPrice(double price) {
            this.price = price;
        }
    }
    
}
