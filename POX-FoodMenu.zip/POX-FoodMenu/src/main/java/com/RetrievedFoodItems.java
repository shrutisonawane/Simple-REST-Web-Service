/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAttribute;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
/**
 *
 * @author Shruti Sonawane
 */
@XmlRootElement(name = "RetrievedFoodItems", namespace="http://cse564.asu.edu/PoxAssignment")
@XmlAccessorType(XmlAccessType.FIELD)
public class RetrievedFoodItems 
{
    @XmlElement(name = "FoodItem", namespace="http://cse564.asu.edu/PoxAssignment")
    private List<RetrievedFoodItems.FoodItem> retrievedFoodItems;
    
    @XmlElement(name = "InvalidFoodItem", namespace="http://cse564.asu.edu/PoxAssignment")
    private List<RetrievedFoodItems.FoodItemId> invalidFoodItems;

    public List<RetrievedFoodItems.FoodItem> getRetrievedFoodItems() 
    {
        return retrievedFoodItems;
    }

    public void setRetrievedFoodItems(List<RetrievedFoodItems.FoodItem> retrievedFoodItems) 
    {
        this.retrievedFoodItems = retrievedFoodItems;
    }

    public List<RetrievedFoodItems.FoodItemId> getInvalidFoodItems() {
        return invalidFoodItems;
    }

    public void setInvalidFoodItems(List<RetrievedFoodItems.FoodItemId> invalidFoodItems) {
        this.invalidFoodItems = invalidFoodItems;
    }
    
     @XmlAccessorType(XmlAccessType.FIELD)
     public static class FoodItem
     {
         @XmlAttribute(name = "country")      
         private String country;
    
         @XmlElement(name = "id", namespace="http://cse564.asu.edu/PoxAssignment")
         private String id;
    
         @XmlElement(name = "name", namespace="http://cse564.asu.edu/PoxAssignment")
         private String name;
    
         @XmlElement(name = "description", namespace="http://cse564.asu.edu/PoxAssignment")
         private String description;
    
         @XmlElement(name = "category", namespace="http://cse564.asu.edu/PoxAssignment")
         private String category;
       
         @XmlElement(name = "price", namespace="http://cse564.asu.edu/PoxAssignment")
         private double price;

        /**
         * @return the country
         */
        public String getCountry() {
            return country;
        }

        /**
         * @param country the country to set
         */
        public void setCountry(String country) {
            this.country = country;
        }

        /**
         * @return the id
         */
        public String getId() {
            return id;
        }

        /**
         * @param id the id to set
         */
        public void setId(String id) {
            this.id = id;
        }

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        /**
         * @param name the name to set
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * @return the description
         */
        public String getDescription() {
            return description;
        }

        /**
         * @param description the description to set
         */
        public void setDescription(String description) {
            this.description = description;
        }

        /**
         * @return the category
         */
        public String getCategory() {
            return category;
        }

        /**
         * @param category the category to set
         */
        public void setCategory(String category) {
            this.category = category;
        }

        /**
         * @return the price
         */
        public double getPrice() {
            return price;
        }

        /**
         * @param price the price to set
         */
        public void setPrice(double price) {
            this.price = price;
        }
  
     }
     
     @XmlAccessorType(XmlAccessType.FIELD)
     public static class FoodItemId
     {
         @XmlElement(name = "FoodItemId")
         private String FoodItemId;

         public String getFoodItemId() 
         {
            return FoodItemId;
        }

        public void setFoodItemId(String FoodItemId) 
        {
            this.FoodItemId = FoodItemId;
        }
     }
}
