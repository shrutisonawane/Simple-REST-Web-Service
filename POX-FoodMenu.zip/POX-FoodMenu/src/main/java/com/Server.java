package com;

/**
 *
 * @author Shruti Sonawane
 */
import com.FoodItemData;
import java.io.File;
import java.util.HashMap;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import com.MyServletContextListener;


public class Server 
{
//    public static String AddFoodItems(String newFoods)
//    {
//       if(MyServletContextListener.foodRepository.containsKey(newFoods))
//         {
//                   
//         }
//    }
    
    
    public static void main(String[] args)
    {
            
    }
    

  
     
}
